<div align="center">

![Mohamed Bensakar](assets/banner.svg)

![ROLE](https://img.shields.io/badge/ROLE-NETWORK_%26_SECURITY_STUDENT-00ffb0?style=for-the-badge&labelColor=050a0f)
![STATUS](https://img.shields.io/badge/STATUS-LEARNING_%26_BUILDING-00e5ff?style=for-the-badge&labelColor=050a0f)
![LOCATION](https://img.shields.io/badge/BASE-MOROCCO-0078d4?style=for-the-badge&labelColor=050a0f)

</div>

![ABOUT_ME](assets/h-about.svg)

```bash
$ whoami
mohamed

$ cat /etc/mohamed.conf
name       = "Mohamed Bensakar"
studying   = ["networks", "cybersecurity"]
building   = "a homelab: Kali, Active Directory, pfSense, GNS3"
practicing = ["TryHackMe", "HackTheBox"]
languages  = ["python", "bash", "powershell"]
mindset    = "trust nothing. verify everything."

$ _
```

I study **networking and cybersecurity**. I build labs, break them in a safe environment, then document what I learned here.

![ARSENAL](assets/h-arsenal.svg)

**Network & Defense**

![Wireshark](https://img.shields.io/badge/Wireshark-1679A7?style=for-the-badge&logo=wireshark&logoColor=white)
![Nmap](https://img.shields.io/badge/Nmap-050a0f?style=for-the-badge&logo=nmap&logoColor=white)
![pfSense](https://img.shields.io/badge/pfSense-212121?style=for-the-badge&logo=pfsense&logoColor=white)
![GNS3](https://img.shields.io/badge/GNS3-2E7D32?style=for-the-badge&logo=gns3&logoColor=white)
![Metasploit](https://img.shields.io/badge/Metasploit-2596CD?style=for-the-badge&logo=metasploit&logoColor=white)

**Systems & Code**

![Kali](https://img.shields.io/badge/Kali%20Linux-557C94?style=for-the-badge&logo=kalilinux&logoColor=white)
![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)
![Windows Server](https://img.shields.io/badge/Windows%20Server-0078D4?style=for-the-badge&logo=windows&logoColor=white)
![Active Directory](https://img.shields.io/badge/Active%20Directory-00539C?style=for-the-badge&logo=microsoft&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Bash](https://img.shields.io/badge/Bash-4EAA25?style=for-the-badge&logo=gnubash&logoColor=white)
![PowerShell](https://img.shields.io/badge/PowerShell-5391FE?style=for-the-badge&logo=powershell&logoColor=white)
![Docker](https://img.shields.io/badge/Docker-2496ED?style=for-the-badge&logo=docker&logoColor=white)

![NETWORK_MAP](assets/h-topology.svg)

| how I think about a network |
| --- |
| `outside` -> untrusted |
| `edge` -> default-deny |
| `inside` -> segmented (VLANs + ACLs) |
| `always` -> logged |

![Lab topology](assets/topology.svg)

![SKILL_SCAN](assets/h-scan.svg)

![Skills as an nmap scan](assets/portscan.svg)

![MISSIONS](assets/h-missions.svg)

| Quest | Status |
| --- | --- |
| Build a homelab: Kali + Active Directory + pfSense | `IN PROGRESS` |
| Document every lab with topology and write-ups | `IN PROGRESS` |
| Automate networking tasks with Python | `IN PROGRESS` |
| Climb the TryHackMe / HackTheBox ranks | `ONGOING` |
| Set up IDS + central logging and tune the alerts | `QUEUED` |
| Land a network / security role | `FINAL BOSS` |

> *keep fighting till the end.*

![TELEMETRY](assets/h-stats.svg)

<div align="center">

![Streak stats](https://github-readme-streak-stats.herokuapp.com/?user=mohamed-bensakar&theme=dark&hide_border=true&background=050a0f&stroke=00ffb0&ring=00e5ff&fire=00ffb0&currStreakLabel=00e5ff&sideLabels=8ff0d0&border_radius=12)

![Contribution snake](https://raw.githubusercontent.com/mohamed-bensakar/mohamed-bensakar/output/snake-dark.svg)

</div>

![PROJECTS](assets/h-projects.svg)

| Project | What it does | Stack |
| --- | --- | --- |
| [**homelab**](https://github.com/mohamed-bensakar/homelab) | Kali, AD and pfSense lab with topology and write-ups | GNS3, pfSense, AD |
| [**network-labs**](https://github.com/mohamed-bensakar/network-labs) | Networking labs with configs and step-by-step docs | Packet Tracer / GNS3 |
| [**net-automation**](https://github.com/mohamed-bensakar/net-automation) | Python scripts for scanning and auditing | Python, Nmap |
| [**cheatsheets**](https://github.com/mohamed-bensakar/cheatsheets) | Nmap, Linux, AD and Wireshark quick references | Markdown |

![COMMS](assets/h-comms.svg)

`> ping me. I inspect every packet.`

[![LinkedIn](https://img.shields.io/badge/LINKEDIN-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white&labelColor=050a0f)](https://www.linkedin.com/in/mohamed-bensakar-864b3b406/)
[![GitHub](https://img.shields.io/badge/GITHUB-00ffb0?style=for-the-badge&logo=github&logoColor=black&labelColor=050a0f)](https://github.com/mohamed-bensakar)
<!-- Add these when you have them (remove the comment markers):
[![TryHackMe](https://img.shields.io/badge/TRYHACKME-212C42?style=for-the-badge&logo=tryhackme&logoColor=white)](https://tryhackme.com/p/YOUR_THM_USERNAME)
[![HackTheBox](https://img.shields.io/badge/HACKTHEBOX-9FEF00?style=for-the-badge&logo=hackthebox&logoColor=black)](https://app.hackthebox.com/users/YOUR_HTB_ID)
[![Email](https://img.shields.io/badge/EMAIL-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:YOUR_EMAIL)
-->

<div align="center">

![Profile views](https://komarev.com/ghpvc/?username=mohamed-bensakar&label=SYSTEM+ACCESSES&color=00ffb0&style=for-the-badge&labelColor=050a0f)

![footer](https://capsule-render.vercel.app/api?type=waving&color=0:050a0f,100:00ffb0&height=120&section=footer&reversal=true)

</div>
